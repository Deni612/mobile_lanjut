package com.example.warnet_billing

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
